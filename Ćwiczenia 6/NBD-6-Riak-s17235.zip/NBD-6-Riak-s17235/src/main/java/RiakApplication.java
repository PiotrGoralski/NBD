import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class RiakApplication {

    public static void main(String[] args) throws IOException {

        //Wrzucenie dokumentu do bazy
        System.out.println("Utworzenie nowego dokumentu");
        URL postUrl = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection postCon = (HttpURLConnection)postUrl.openConnection();
        postCon.setRequestMethod("POST");
        postCon.setRequestProperty("Content-Type", "application/json");
        postCon.setRequestProperty("Accept", "application/json");
        postCon.setDoOutput(true);
        String jsonInputString = "{\"brand\": \"Opel\", \"production-year\": 2004, \"need-fix\": true, \"fuel-consumption\": 6.5}";
        try(OutputStream os = postCon.getOutputStream()) {
            byte[] input = jsonInputString.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        try(BufferedReader br = new BufferedReader(new InputStreamReader(postCon.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(postCon.getResponseMessage());
            System.out.println(response);
        } catch (IOException e) {
            System.out.println(postCon.getResponseMessage());
        }

        System.out.println();

        //Pobranie i wypisanie dokumentu z bazy
        System.out.println("Pobranie i wypisanie dokumentu");
        JSONObject obj = new JSONObject();
        URL getUrl = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection getCon = (HttpURLConnection)getUrl.openConnection();
        getCon.setRequestMethod("GET");
        getCon.setRequestProperty("Content-Type", "application/json");
        getCon.setRequestProperty("Accept", "application/json");
        getCon.setDoOutput(true);
        try(BufferedReader br = new BufferedReader(new InputStreamReader(getCon.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            obj = new JSONObject(response.toString());
            System.out.println(getCon.getResponseMessage());
            System.out.println(obj.toString());
        } catch (IOException e) {
            System.out.println(getCon.getResponseMessage());
        }

        System.out.println();

        //modyfikacja dokumentu i zapis
        System.out.println("Aktualizacja dokumentu");
        URL updateUrl = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection updateCon = (HttpURLConnection)updateUrl.openConnection();
        updateCon.setRequestMethod("PUT");
        updateCon.setRequestProperty("Content-Type", "application/json");
        updateCon.setRequestProperty("Accept", "application/json");
        updateCon.setDoOutput(true);
        obj.put("fuel-consumption", "8.0");
        try(OutputStream os = updateCon.getOutputStream()) {
            byte[] input = obj.toString().getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        try(BufferedReader br = new BufferedReader(new InputStreamReader(updateCon.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(updateCon.getResponseMessage());
            System.out.println(response);
        } catch (IOException e) {
            System.out.println(updateCon.getResponseMessage());
        }

        System.out.println();

        //Pobranie i wypisanie dokumentu z bazy
        System.out.println("Pobranie i wypisanie zaktualizowanego dokumentu");
        URL getUrl_zaktualizowany = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection getCon_zaktualizowany = (HttpURLConnection)getUrl_zaktualizowany.openConnection();
        getCon_zaktualizowany.setRequestMethod("GET");
        getCon_zaktualizowany.setRequestProperty("Content-Type", "application/json");
        getCon_zaktualizowany.setRequestProperty("Accept", "application/json");
        getCon_zaktualizowany.setDoOutput(true);
        try(BufferedReader br = new BufferedReader(new InputStreamReader(getCon_zaktualizowany.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(getCon_zaktualizowany.getResponseMessage());
            System.out.println(response);
        } catch (IOException e) {
            System.out.println(getCon_zaktualizowany.getResponseMessage());
        }

        System.out.println();

        //Usunięcie dokumentu z bazy
        System.out.println("Usuniecie dokumentu");
        URL deleteUrl = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection deleteCon = (HttpURLConnection)deleteUrl.openConnection();
        deleteCon.setRequestMethod("DELETE");
        deleteCon.setRequestProperty("Content-Type", "application/json");
        deleteCon.setRequestProperty("Accept", "application/json");
        deleteCon.setDoOutput(true);
        System.out.println(deleteCon.getResponseMessage());
        try(BufferedReader br = new BufferedReader(new InputStreamReader(deleteCon.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(deleteCon.getResponseMessage());
            System.out.println(response);
        } catch (IOException e) {
            System.out.println(deleteCon.getResponseMessage());
        }

        System.out.println();

        //Pobranie i wypisanie dokumentu z bazy po usunięciu
        System.out.println("Pobranie i wypisanie usunietego dokumentu");
        URL getUrl_usuniety = new URL ("http://localhost:8098/buckets/s17235/keys/carOpel");
        HttpURLConnection getCon_usuniety = (HttpURLConnection)getUrl_usuniety.openConnection();
        getCon_usuniety.setRequestMethod("GET");
        getCon_usuniety.setRequestProperty("Content-Type", "application/json");
        getCon_usuniety.setRequestProperty("Accept", "application/json");
        getCon_usuniety.setDoOutput(true);
        try(BufferedReader br = new BufferedReader(new InputStreamReader(getCon_usuniety.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(getCon_usuniety.getResponseMessage());
            System.out.println(response);
        } catch (IOException e) {
            System.out.println(getCon_usuniety.getResponseMessage());
        }

    }

}
